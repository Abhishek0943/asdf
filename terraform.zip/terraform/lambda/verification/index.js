// file: handler.js
const mongoose = require('mongoose');
const crypto = require('crypto');

/* ---------------------------- Error + Utilities --------------------------- */
class ErrorHandler extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
    if (Error.captureStackTrace) Error.captureStackTrace(this, this.constructor);
  }
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  'Access-Control-Allow-Methods': 'OPTIONS,POST',
  'Content-Type': 'application/json',
};

const jsonResponse = (statusCode, body) => ({
  statusCode,
  headers: corsHeaders,
  body: JSON.stringify(body),
});

function parseJsonBody(event) {
  if (!event.body) return null;
  try {
    const raw = event.isBase64Encoded
      ? Buffer.from(event.body, 'base64').toString('utf8')
      : event.body;
    return JSON.parse(raw);
  } catch {
    return event.body; // if invalid JSON, let validation handle it
  }
}

/** Stable stringify so hashing the payload is deterministic */
function stableStringify(value) {
  const seen = new WeakSet();
  const recur = (v) => {
    if (v && typeof v === 'object') {
      if (seen.has(v)) return '[Circular]';
      seen.add(v);
      if (Array.isArray(v)) return v.map(recur);
      return Object.keys(v)
        .sort()
        .reduce((acc, k) => {
          acc[k] = recur(v[k]);
          return acc;
        }, {});
    }
    return v;
  };
  return JSON.stringify(recur(value));
}

/** Replace with your real logic if different */
function credentialId(payload) {
  return crypto.createHash('sha256').update(stableStringify(payload)).digest('hex');
}

/* --------------------------------- DB ------------------------------------ */
let cachedConn = null;

async function connectDB() {
  if (cachedConn && cachedConn.readyState === 1) return cachedConn;
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new ErrorHandler('MONGODB_URI not set', 500);
  if (!cachedConn) {
    await mongoose.connect(uri, {
      maxPoolSize: 5,
      serverSelectionTimeoutMS: 5000,
    });
    cachedConn = mongoose.connection;
  }
  return cachedConn;
}

/* ------------------------------ Mongoose Model --------------------------- */
const { Schema } = mongoose;

const CredentialSchema = new Schema(
  {
    _id: { type: String, required: true },  
    payload: { type: Schema.Types.Mixed, required: true },
    issued_at: { type: Date, required: true, default: () => new Date() },
    worker_id: { type: String, required: true },
  },
  { timestamps: true }
);

CredentialSchema.index({ worker_id: 1, issued_at: -1 });

const Credential =
  mongoose.models.Credential || mongoose.model('Credential', CredentialSchema);

/* ----------------------------- Lambda Wrapper ---------------------------- */
const catchAsync = (fn) => async (event) => {
  try {
    return await fn(event);
  } catch (err) {
    const status = err instanceof ErrorHandler && err.statusCode ? err.statusCode : 500;
    const message = err?.message || (status === 500 ? 'Internal Server Error' : 'Request failed');
    console.error('Lambda error:', { status, message, stack: err?.stack });
    return jsonResponse(status, { error: message });
  }
};

/* -------------------------------- Handler -------------------------------- */
const handler = catchAsync(async (event) => {
  // CORS preflight
  const method = event.requestContext?.http?.method || event.httpMethod; // supports REST or HTTP API
  if (method === 'OPTIONS') return { statusCode: 204, headers: corsHeaders, body: '' };
  if (method !== 'POST') return jsonResponse(405, { error: 'Method Not Allowed' });

  const payload = parseJsonBody(event);
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)) {
    throw new ErrorHandler('Invalid credential JSON', 400);
  }

  await connectDB();

  const id = credentialId(payload);
  const rec = await Credential.findById(id).lean();

  if (!rec) throw new ErrorHandler('credential not found', 404);

  return jsonResponse(200, {
    valid: true,
    id,
    issued_at: rec.issued_at,
    worker: `credential issued by ${rec.worker_id}`,
    verified_at: new Date().toISOString(),
    success:true
  });
});

module.exports.handler = handler;
