#!/bin/bash
set -euxo pipefail
exec > /var/log/user-data.log 2>&1

# --- Update and install Docker ---
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y ca-certificates curl git docker.io

# --- Start and enable Docker ---
systemctl enable --now docker

# --- Clone your project ---
git clone https://github.com/Abhishek0943/asdf.git /opt/app
cd /opt/app

# --- Build the combined frontend+backend image ---
docker build -t app:local .

# --- Stop old container if exists ---
docker rm -f app || true

# --- Run new container ---
docker run -d --name app --restart unless-stopped -p 80:3000 app:local

# --- Log info ---
echo "Container running on port 80"
docker ps
